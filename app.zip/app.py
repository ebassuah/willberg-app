from pathlib import Path
import os
import sys

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QFont

from fms.core.db import Database
from fms.core.migrations import migrate
from fms.ui.main_window import MainWindow
from fms.ui.dialogs.login_dialog import LoginDialog


def main() -> int:
    # os.environ.setdefault(
    #     "QTWEBENGINE_CHROMIUM_FLAGS",
    #     "--disable-gpu --disable-software-rasterizer --disable-gpu-sandbox "
    #     "--use-gl=swiftshader --use-angle=swiftshader",
    # )
    app = QApplication(sys.argv)
    app.setFont(QFont("Roboto", 10))

    db_path = Path("data") / "willberg_fms.db"
    db = Database(db_path)
    migrate(db)

    window = None

    def show_login():
        login = LoginDialog(db)
        if not login.exec():
            return None
        return login.user

    def show_main(user):
        nonlocal window
        window = MainWindow(db, current_user=user)
        window.logout_requested.connect(handle_logout)
        window.show()

    def handle_logout():
        nonlocal window
        if window:
            window.close()
            window = None
        user = show_login()
        if user is None:
            app.quit()
            return
        show_main(user)

    user = show_login()
    if user is None:
        return 0
    show_main(user)

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
